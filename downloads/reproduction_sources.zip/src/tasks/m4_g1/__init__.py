"""M4 semantic-map G1 navigation experiments."""
